/*
			设置屏幕和输入框的宽度
		 */
		function initScreen() {
			$('.screen').css({
				height : height,
				width : width
			});
			$('.a1').css({
				height : height-100,
				width : width
			});
			$('.inputArea').css({
				width : width
			});
		}
		//获得随机位置
		function getRandomTop() {
			return Math.random() * (height - 150);
		}
		//获得随机颜色
		function getRandomColor() {
			var color = '#';
			for ( var i = 0; i < 3; i++) {
				color += Math.ceil(Math.random() * 255).toString(16);
			}
			return color;
		}
		//把弹幕文字发射到屏幕中
		function addTxt2Screen(txt){
			var name="txt"+i;
			i++;
			$('.screen').prepend( '<font class='+name+'>'+txt+'</font>');
			name=".screen ."+name;
			var x = $(name).width();
			$(name).css({left:width-x,top:getRandomTop(),color:getRandomColor()});
			
			$(name).animate({
				left : -width + x
			}, 10000, function() {
				//移除该文字
				$(this).remove();
			});
		}
		//视频加载事件
		function loadedHandler(){
		 if(CKobject.getObjectById('ckplayer_a1').getType()){
		      CKobject.getObjectById('ckplayer_a1').addListener('ended',endedHandler);
		      CKobject.getObjectById('ckplayer_a1').addListener('time',timeHandler);
		    }
		    else{
		      CKobject.getObjectById('ckplayer_a1').addListener('ended','endedHandler');
		      CKobject.getObjectById('ckplayer_a1').addListener('time','timeHandler');
		    }
		}
		function endedHandler(){
			if(videoAddress)
			{
				CKobject.getObjectById('ckplayer_a1').newAddress('{p->1}{f->http://123.207.172.86/ckplayer/video/dusk.mp4}{html5->http://123.207.172.86/ckplayer/video/dusk.mp4->video/mp4}')
			}
			else
			{
				CKobject.getObjectById('ckplayer_a1').newAddress('{p->1}{f->http://123.207.172.86/ckplayer/video/jannina weigel.mp4}{html5->http://123.207.172.86/ckplayer/video/jannina weigel.mp4->video/mp4}')
			}
			videoAddress=!videoAddress;
		}
		function danmu(msg,time){
			this.msg=msg;
			this.time=time;
		}
		/*
		 * video播放事件
		 * 第一次向数据库发送AJAX请求来获取所有弹幕
		 * */
		function timeHandler(t){
			time=t;
			if(isFirst){
				isFirst=false;
				//ajax请求获取数据库中所有弹幕
				$.ajax({
					url:"DanMu/DanMu_query.action",
					type:"get",
					success:function(data){
						allDanmu=data.split(";");
						for(var i=0;i<allDanmu.length;i++){
							var temp=allDanmu[i].split(",");
							var x=new danmu(temp[0],temp[1]);
							danmuList[i]=x;	
						}
						danmuLen=danmuList.length;
					}
				});
			}
			while(index<danmuLen){
				if(Math.abs(danmuList[index].time-time)<0.3||danmuList[index].time<t){
					addTxt2Screen(danmuList[index].msg);
					index++;
					continue;
				}
				break;
			}
		}