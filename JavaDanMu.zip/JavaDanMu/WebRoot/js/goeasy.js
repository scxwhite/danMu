		var goeasy = new GoEasy({
            appkey: 'BS-6cab73eced1440c582eaf081488cf917'
             });
		goeasy.subscribe({
		          channel: 'DanMu',
		onMessage: function (result) {
			//将其它客户端发送的消息显示到屏幕
			addTxt2Screen(result.content);
		}
		});	