package com.scx.dao;

import java.util.List;

import com.scx.domain.DanMu;

public interface DanMuDao {
	void add(DanMu danMu);
	List<DanMu> query(double time);
	List<DanMu> queryAll();
}
