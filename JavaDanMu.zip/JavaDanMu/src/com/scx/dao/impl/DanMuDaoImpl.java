package com.scx.dao.impl;

import java.util.List;

import org.hibernate.Session;

import com.scx.dao.DanMuDao;
import com.scx.domain.DanMu;
import com.xynu.util.SessionFactoryUtil;

public class DanMuDaoImpl implements DanMuDao{

	public void add(DanMu danMu) {
		Session session=SessionFactoryUtil.getCurrentSession();
		session.save(danMu);
	}


	@SuppressWarnings("unchecked")
	public List<DanMu> query(double time) {
		Session session=SessionFactoryUtil.getCurrentSession();
		return session.createQuery("from DanMu where ABS(?-time)<0.3").setDouble(0, time).list();
	}

	@SuppressWarnings("unchecked")
	public List<DanMu> queryAll() {
		Session session=SessionFactoryUtil.getCurrentSession();
		return session.createQuery("from DanMu order by time").list();
	}
}
