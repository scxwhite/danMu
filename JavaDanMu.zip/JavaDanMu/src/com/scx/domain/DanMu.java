package com.scx.domain;

public class DanMu {
	private Integer id;
	private String msg;
	private double time;
	public DanMu(){
		
	}
	public DanMu(String msg, double time) {
		this.msg=msg;
		this.time=time;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public double getTime() {
		return time;
	}
	public void setTime(double time) {
		this.time = time;
	}
	
	
}
