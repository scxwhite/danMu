﻿package com.scx.web.action;

import io.goeasy.GoEasy;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import com.scx.dao.DanMuDao;
import com.scx.dao.impl.DanMuDaoImpl;
import com.scx.domain.DanMu;

public class DanMuAjaxAction extends SuperAction{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8048027371928398743L;
	private DanMuDao dmDao=new DanMuDaoImpl();
	GoEasy go=new GoEasy("your key");//填写你自己的
	private String txt;
	private double time;
	public void add(){
		//使用goeasy第三方推送服务 向相同频道的其它用户推送消息
		go.publish("DanMu", txt);
		//将弹幕内容和时间保存到数据库
		dmDao.add(new DanMu(txt,time));
	}
	public void search() throws IOException {
		List<DanMu> list=dmDao.query(time);
		String res="";
		for (DanMu danMu : list) {
			res+=danMu.getMsg()+";";
		}
		PrintWriter pw=response.getWriter();
		pw.write(res);
		pw.flush();
		pw.close();
	}
	public void query() throws IOException {
		List<DanMu> list=dmDao.queryAll();
		String res="";
		for (DanMu danMu : list) {
			res+=danMu.getMsg()+","+danMu.getTime()+";";
		}
		PrintWriter pw=response.getWriter();
		pw.write(res);
		pw.flush();
		pw.close();
	}
	public String getTxt() {
		return txt;
	}
	public void setTxt(String txt) {
		this.txt = txt;
	}
	public double getTime() {
		return time;
	}
	public void setTime(double time) {
		this.time = time;
	}
}
