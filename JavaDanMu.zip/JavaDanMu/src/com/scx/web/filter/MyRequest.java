package com.scx.web.filter;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

/*
 * ����ת������
 * */
public class MyRequest extends HttpServletRequestWrapper{
	private Map<String, String[]> params=new HashMap<String, String[]>();
	@SuppressWarnings("unchecked")
	public MyRequest(HttpServletRequest request) {
		super(request);
		
		Map <String,String[]> map = super.getParameterMap();
		
		if(map!=null&&map.size()>0){
			for(Entry<String, String[]> e:map.entrySet()){
				String [] values=e.getValue();
				int len=values.length;
				if(values!=null&&values.length>0){
					String []newValue=new String[len];
					for(int i=0;i<len;i++){
						try {
							newValue[i]=new String(values[i].getBytes("ISO-8859-1"), "UTF-8");
						} catch (UnsupportedEncodingException e1) {
							e1.printStackTrace();
						}
					}
					
					params.put(e.getKey(),newValue);
				}
			}
		}
	}
	@Override
	public String getParameter(String name) {
		String [] param=params.get(name);
		if(param==null) return null;
		return param[0];
	}
	@Override
	public Map<String,String[]> getParameterMap() {
		return params;
	}
	@Override
	public String[] getParameterValues(String name) {
		return params.get(name);
	}
	
}
