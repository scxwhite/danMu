package com.scx.web.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.xynu.util.SessionFactoryUtil;
/*
 * �������
 * */
public class SessionFactoryFilter implements Filter {

	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		
		Session session = SessionFactoryUtil.getCurrentSession();
		Transaction tx = session.beginTransaction();
		try {
			chain.doFilter(request, response);
			if(session!=null&&session.isOpen()){
				tx.commit();
			}
		} catch (Exception e) {
			e.printStackTrace();
			if(session!=null&&session.isOpen()){
				tx.rollback();
			}
		}
	}

	public void init(FilterConfig filterConfig) throws ServletException {
		
	}
	
}
